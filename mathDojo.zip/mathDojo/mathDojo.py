class MathDojo:
    def __init__(self):
        self.resultado = 0
    
    def suma(self,num1,*nums):
        suma = num1
        for numero in nums:
            suma = suma + numero
        self.resultado = suma
        return self
    
    def resta(self,num1,*nums):
        resta = num1
        for numero in nums:
            resta = resta - numero
        self.resultado = resta
        return self
    
    def mostrar(self):
        print(f'El resultado es: {self.resultado}')
        return self
    
