from mathDojo import MathDojo

md = MathDojo()
md.resta(5,10,4).mostrar()
md.resta(10,4,5).mostrar()
md.resta(6,7,8).mostrar()
md.suma(1,2,3).mostrar()
md.suma(2,3,4).mostrar()
md.suma(5,2,8).mostrar()