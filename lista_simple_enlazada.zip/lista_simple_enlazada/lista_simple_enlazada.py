from clase_nodo import SLNode
from clase_lista import SList     

        
if __name__ == '__main__':
    my_list = SList()
    my_list.add_to_front("son").add_to_front("Las listas enlazadas").add_to_back("divertidas!").print_values()
    my_list.remove_val('son').print_values()
    my_list.insert_at('son muy jodidas y ','Las listas enlazadas').print_values()