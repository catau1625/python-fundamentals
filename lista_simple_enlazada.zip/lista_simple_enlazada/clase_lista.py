from clase_nodo import SLNode
# Definiendo la clase lista
class SList:
    def __init__(self):
        self.head = None
        
    def add_to_front(self,val):
        new_node = SLNode(val) # Se crea una nueva instancia de clase Node el valor 'val'
        current_head = self.head # guarda el head actual en una variable
        new_node.next = current_head # ESTABLECE el nuevo nodo JUNTO AL encabezado actual de la lista
        self.head = new_node # FIJA el encabezado de la lista al ultimo nodo agregado
        return self 
    
    def print_values(self):
        runner = self.head # puntero al primer nodo de la lista
        while (runner != None): # se mantiene la iteracion mientras runner sea distinto de None
            print(runner.val) # imprime el valor de runner
            runner = runner.next # establece runner = valor siguiente a runner actual
        return self
    
    def add_to_back(self,val):
        
        # agregaremos una funcion en caso de que la lista este vacia
        if self.head == None: # si no hay un primer elemento
            self.add_to_front(val) # ejecuta la funcion add_to_front
            return self
        
        new_node = SLNode(val) # Crea una nueva instancia de clase Node con valor = val
        runner = self.head # establece una variable que se inicia al comienzo de la lista
        while (runner.next != None): # se recorre la lista hasta que el elemento en cuestion no tenga vecino
            runner = runner.next # establece runner como el siguiente nodo de la lista
        runner.next = new_node # establece el nuevo nodo en la posicion siguiente al ultimo runner
        return self
    
    def remove_from_front(self):
        if self.head == None:
            print("No hay elementos en la lista")
            return self
        
        pop_elem = self.head
        print(f"Eliminando el elemento: {pop_elem.val}")
        self.head = pop_elem.next
        pop_elem = None
        return self
        
    
    def remove_from_back(self):
        if self.head == None:
            print("No hay elementos en la lista!!")
            return self
        
        pop_elem = self.head # establece una variable que se inicia al comienzo de la lista
        while pop_elem.next.next != None:
            pop_elem = pop_elem.next
        pop_elem.next = None
        return self
    
    def remove_val(self,val):
        if self.head == None:
            print("No hay elementos en la lista!!")
            return self
        
        pop_elem = self.head # establece una variable que se inicia al comienzo de la lista
        while pop_elem.next.val != val:
            pop_elem = pop_elem.next
        print(f"Eliminando el elemento: {pop_elem.next.val}")
        pop_elem.next = pop_elem.next.next
        return self
    
    def insert_at(self,val,next_to):
        if self.head == None:
            print("No hay elementos en la lista!!")
            return self
        
        new_node = SLNode(val)
        insert_elem = self.head # establece una variable que se inicia al comienzo de la lista
        while insert_elem.val != next_to:
            insert_elem = insert_elem.next
        current_element = insert_elem
        new_node.next = current_element.next
        current_element.next = new_node
        return self