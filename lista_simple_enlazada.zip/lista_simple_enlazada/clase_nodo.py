# Definiendo la clase Nodo
class SLNode:
    def __init__(self,val):
        self.val = val
        self.next = None