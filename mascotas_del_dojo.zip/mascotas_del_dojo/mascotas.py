from importlib.metadata import SelectableGroups
from typing_extensions import Self


class Mascota:
    def __init__(self,nombre,tipo,golosinas,salud=100,energia=100):
        self.nombre = nombre
        self.tipo = tipo
        self.golosinas = golosinas
        self.salud = salud
        self.energia = energia
        
    def dormir(self):
        self.energia = self.energia + 25
        return self
    
    def comer(self):
        self.energia = self.energia + 5
        self.salud = self.salud + 10
        return self
    
    def jugar(self):
        self.salud = self.salud + 5
        return self
    
    def sonido(self):
        if self.tipo == 'perro':
            print('guau guau')
        elif self.tipo == 'gato':
            print('miau miau')
        else:
            print('????')
