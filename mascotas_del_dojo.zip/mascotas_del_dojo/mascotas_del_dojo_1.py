class Ninja:
    def __init__(self,nombre,apellido,mascota,premio,comida_mascota):
        self.nombre = nombre
        self.apellido = apellido
        self.mascota = mascota
        self.premio = premio
        self.comida_mascota = comida_mascota
    
    def caminar(self,mascota):
        mascota.jugar()
        return self
    
    def alimentar(self,mascota):
        mascota.comer()
        return self
    
    def bañar(self,mascota):
        mascota.sonido()
        return self
    
class Mascota:
    def __init__(self,nombre,tipo,golosinas,salud=100,energia=100):
        self.nombre = nombre
        self.tipo = tipo
        self.golosinas = golosinas
        self.salud = salud
        self.energia = energia
        
    def dormir(self):
        self.energia = self.energia + 25
        return self
    
    def comer(self):
        self.energia = self.energia + 5
        self.salud = self.salud + 10
        return self
    
    def jugar(self):
        self.salud = self.salud + 5
        return self
    
    def sonido(self):
        if self.tipo == 'perro':
            print('guau guau')
        elif self.tipo == 'gato':
            print('miau miau')
        else:
            print('????')
            
if __name__ == "__main__":
    mascota1 = Mascota('pelusin','gato','croquetas de atun')
    ninja1 = Ninja('pedrito','perez',mascota1,'croquetas de atun','proplan')
    ninja1.alimentar(mascota1)
    print(mascota1.salud,mascota1.energia)
    ninja1.bañar(mascota1)