class Ninja:
    def __init__(self,nombre,apellido,mascota,premio,comida_mascota):
        self.nombre = nombre
        self.apellido = apellido
        self.mascota = mascota
        self.premio = premio
        self.comida_mascota = comida_mascota
    
    def caminar(self,mascota):
        mascota.jugar()
        return self
    
    def alimentar(self,mascota):
        mascota.comer()
        return self
    
    def bañar(self,mascota):
        mascota.sonido()
        return self