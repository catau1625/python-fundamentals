from mascotas import Mascota
from mascotas import Tortugas
from ninjas import Ninja

mascota1 = Mascota('pelusin','gato','croquetas de atun')
ninja1 = Ninja('pedrito','perez',mascota1,'croquetas de atun','proplan')
ninja1.alimentar(mascota1)
print("Salud:",mascota1.salud,"Energia:",mascota1.energia)
ninja1.bañar(mascota1)
ninja1.caminar(mascota1)
print("Salud:",mascota1.salud,"Energia:",mascota1.energia)
mascota2 = Tortugas('melisa')
ninja2 = Ninja('paloma','mami',mascota2,'galletitas de tortuga','taste of the wild')
ninja2.alimentar(mascota2)
print("Salud:",mascota2.salud,"Energia:",mascota2.energia)
