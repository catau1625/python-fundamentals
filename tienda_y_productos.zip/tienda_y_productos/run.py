from producto import Producto
from tienda import Tienda

tienda1 = Tienda('La super tienda','lasupertienda@gmail.com')

tienda1.agregar_producto(1,'tecnologia','audifonos',30000)
tienda1.info_tienda()
tienda1.liquidacion(0.34)
tienda1.info_tienda()
tienda1.vender_producto(1)
tienda1.info_tienda()
