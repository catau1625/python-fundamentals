from producto import Producto
class Tienda:
    def __init__(self, nombre, email):
        self.nombre = nombre
        self.email = email
        self.productos = {}
        
    def agregar_producto(self,id,tipo_producto,sub_tipo_producto,precio):
        self.productos[id]=Producto(tipo_producto,sub_tipo_producto,precio)
        return self
    
    def vender_producto(self,id_producto):
        self.productos.pop(id_producto)
        return self
    
    def inflacion(self,porcentaje_aumento):
        for i in self.productos:
            self.productos[i].actualizar_precio(porcentaje_aumento)
        return self
    
    def liquidacion(self,porcentaje_liquidacion):
        for i in self.productos:
            self.productos[i].actualizar_precio(-porcentaje_liquidacion)
        return self
    
    def info_tienda(self):
        if not self.productos:
            print('No hay productos disponibles')
        else:
            for i in self.productos:
                self.productos[i].print_info()
        return self
