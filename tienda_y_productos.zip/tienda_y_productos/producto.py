class Producto:
    def __init__(self,tipo,sub_tipo,precio):
        self.tipo = tipo
        self.sub_tipo = sub_tipo
        self.precio = precio
    
    def print_info(self):
        print(f'Tipo: {self.tipo}')
        print(f'Sub_tipo: {self.sub_tipo}')
        print(f'Precio: {self.precio}')
        return self
    
    def actualizar_precio(self,nuevo_precio):
        if nuevo_precio < 1:
            self.precio = self.precio * (1+ nuevo_precio)
        else:
            self.precio = nuevo_precio
        return self
    
    