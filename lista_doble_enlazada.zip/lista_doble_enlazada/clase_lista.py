from unittest import runner
from clase_nodo import Nodo

class Lista:
    def __init__(self):
        self.head = None
    
    def agregar_nodo_right(self,val_nodo,next_to=None):
        new_nodo = Nodo(val_nodo)
        if self.head == None:
            self.head = new_nodo
            return self
        if next_to == None:
            print("No se a agregado un valor de referencia a la funcion agregar_nodo_right")
            return self  
        
        insert_elem = self.head # establece una variable que se inicia al comienzo de la lista
        while insert_elem.val != next_to:
            insert_elem = insert_elem.next
        if insert_elem.next == None:
            insert_elem.next = new_nodo
            new_nodo.prev = insert_elem
            return self
        current_element = insert_elem
        new_nodo.next = current_element.next
        current_element.next = new_nodo
        new_nodo.prev = current_element
        return self
    
    def agregar_nodo_left(self,val_nodo,prev_to=None):
        new_nodo = Nodo(val_nodo)
        if self.head == None:
            self.head = new_nodo
            return self
        if prev_to == None:
            print("No se a agregado un valor de referencia a la funcion agregar_nodo_left")
            return self  
        if prev_to == self.head.val:
            current_head = self.head # guarda el head actual en una variable
            new_nodo.next = current_head # ESTABLECE el nuevo nodo JUNTO AL encabezado actual de la lista
            self.head = new_nodo
            return self
        runner = self.head # establece una variable que se inicia al comienzo de la lista
        while runner.val != prev_to:
            runner = runner.next


        current_element = runner
        new_nodo.prev = current_element.prev
        new_nodo.next = current_element
        current_element.prev = new_nodo
        new_nodo.prev.next = new_nodo
        return self
    
    def print_values(self):
        if self.head == None:
            print("La lista no contiene elementos")
            return self
        print("Los valores almacenados en la lista son:")
        runner = self.head # puntero al primer nodo de la lista
        while (runner != None): # se mantiene la iteracion mientras runner sea distinto de None
            print(runner.val) # imprime el valor de runner
            runner = runner.next # establece runner = valor siguiente a runner actual
        return self
    
    def remove_val(self,val):
        if self.head == None:
            print("No hay elementos en la lista!!")
            return self
        
        runner = self.head # establece una variable que se inicia al comienzo de la lista
        while runner.val != val: 
            runner = runner.next
        print(f"Eliminando el elemento: {runner.val}")
        if runner.next == None:
            runner.prev.next = None
            runner = None
            return self
        if runner == self.head:
            self.head = runner.next
            runner = None
            return self
        else:
            runner.next.prev = runner.prev
            runner.prev.next = runner.next
            runner = None
            return self