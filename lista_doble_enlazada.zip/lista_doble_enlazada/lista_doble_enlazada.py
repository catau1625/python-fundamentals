from clase_lista import Lista
from clase_nodo import Nodo

my_list = Lista()

my_list.agregar_nodo_left('Valor 1').agregar_nodo_right('Valor 2','Valor 1').agregar_nodo_left('Valor 0','Valor 2').agregar_nodo_right('Valor 3','Valor 2').print_values()
