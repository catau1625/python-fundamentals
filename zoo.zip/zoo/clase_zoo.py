class Zoo:
    def __init__(self,nombre_zoo):
        self.animales = []
        self.name = nombre_zoo
        
    def agregar_animal(self,animal):
        self.animales.append(animal)
        return self
    
    def info_zoo(self):
        for animal in self.animales:
            animal.mostrar_info()
        return self
