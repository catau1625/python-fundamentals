from distutils.log import info
from unicodedata import name


class Animal:
    def __init__(self,nombre,tipo):
        self.nombre = nombre
        self.salud = 100
        self.felicidad = 100
        self.energia = 100
        self.tipo = tipo
        
    def comer(self,aumento1,aumento2,aumento3):
        self.salud += aumento1
        self.energia += aumento2
        self.felicidad += aumento3
        return self
    
    def dormir(self,aumento1,aumento2):
        self.salud += aumento1
        self.energia += aumento2
        return self
    
    def jugar(self,aumento1,aumento2):
        self.energia += aumento1
        self.felicidad += aumento2
        return self
    
    def mostrar_info(self):
        print(f'Nombre: {self.nombre}')
        print(f'Tipo: {self.tipo}')
        print(f'Energia: {self.energia}')
        print(f'Salud: {self.salud}')
        print(f'Felicidad: {self.felicidad}\n')
        return info
    
class Leon(Animal):
    def __init__(self,name):
        super().__init__(name,tipo= 'Leon')
        
    def comer(self):
        super().comer(20,30,20)
        return self
    
    def dormir(self):
        super().dormir(10,30)
        return self
    
    def jugar(self):
        super().jugar(-40,50)
        return self
    
    def mostrar_info(self):
        return super().mostrar_info()
    
class Tigre(Animal):
    def __init__(self,name):
        super().__init__(name,tipo= 'Tigre')
        
    def comer(self):
        super().comer(40,20,10)
        return self
    
    def dormir(self):
        super().dormir(40,60)
        return self
    
    def jugar(self):
        super().jugar(-70,30)
        return self
    
    def mostrar_info(self):
        return super().mostrar_info()
    
class Oso(Animal):
    def __init__(self,name):
        super().__init__(name,tipo= 'Oso')
        
    def comer(self):
        super().comer(20,30,40)
        return self
    
    def dormir(self):
        super().dormir(30,50)
        return self
    
    def jugar(self):
        super().jugar(-50,20)
        return self
    
    def mostrar_info(self):
        return super().mostrar_info()