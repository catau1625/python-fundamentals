from clase_zoo import Zoo
from clase_animal import Animal,Leon,Tigre,Oso

leon1 = Leon('Gran Cachupin')
oso1 = Oso('Yogui')
tigre1 = Tigre('Sherkan')
zoo1 = Zoo('Super Zoo')

zoo1.agregar_animal(leon1).agregar_animal(oso1).agregar_animal(tigre1).info_zoo()
print('******************')
leon1.comer().dormir().mostrar_info()
print('******************')
oso1.jugar().comer().mostrar_info()
print('******************')
tigre1.comer().dormir().mostrar_info()